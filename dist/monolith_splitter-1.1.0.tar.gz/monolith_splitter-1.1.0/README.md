# Monolith Splitter

Split a monolithic Python file into reusable module files from a simple CSV map.

This project helps turn one large script into a cleaner package structure by letting you define sections such as `MAIN`, `UTILITIES`, `MODEL`, and `REPORTING` in a CSV, then export each slice to a separate `.py` file.

## What it does

- Reads a source Python file
- Parses section ranges from a CSV config
- Extracts each section in order
- Re-enables commented imports inside the chunk
- Writes each section to its own file
- Warns when ranges are left unassigned

## Project layout

The package now uses a proper `src` layout:

```text
monolith_splitter/
├── src/
│   └── monolith_splitter/
│       ├── __init__.py
│       └── core.py
├── tests/
├── example/
├── pyproject.toml
├── README.md
└── main.py
```

## Installation

### Install from wheel

```bash
python3 -m pip install dist/monolith_splitter-1.1.0-py3-none-any.whl
```

### Install from the project directory

```bash
python3 -m pip install .
```

## Quick usage

```bash
monolith-splitter --src example/main.py --cfg example/inif.csv --out output
```

## Example CSV

```csv
SECTION_NAME,START_LINE,END_LINE
MAIN.py,3,12
UTILITIES,13,37
DATA_LOADING,38,58
MODEL,78,100
```

This produces files like:

- `main.py`
- `UTILITIES.py`
- `DATA_LOADING.py`
- `MODEL.py`

## CLI commands

```bash
monolith-splitter --help
monolith-splitter --version
```

## Example output

```text
WARNING: Unassigned line ranges:
Lines 1-2
Wrote output/main.py
Wrote output/UTILITIES.py
Wrote output/DATA_LOADING.py
```

## Notes

The repository includes example files so you can run the tool immediately without creating your own input first.

