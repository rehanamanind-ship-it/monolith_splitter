"""Monolith Splitter package."""

from .core import (
    ConfigError,
    Section,
    __version__,
    extract_lines,
    main,
    normalize_filename,
    output_filename_for,
    parse_config,
    report_unassigned,
    uncomment_imports,
    validate_sections,
    write_output,
)

__all__ = [
    "ConfigError",
    "Section",
    "__version__",
    "extract_lines",
    "main",
    "normalize_filename",
    "output_filename_for",
    "parse_config",
    "report_unassigned",
    "uncomment_imports",
    "validate_sections",
    "write_output",
]
